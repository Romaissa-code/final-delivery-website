<?php 

include "../mainPage/connexion/submit.php" ;
session_start();

if(!$_SESSION["valid"])
{
    //Do not show protected data, redirect to login...
    header('Location: http://localhost/mainPage/');
}

 include '../mainPage/fpdf184/fpdf.php' ; 
 require '../mainPage/code/vendor/autoload.php';
//the tracking process

$sql="SELECT * FROM `scannedcode`;" ; 

$data=mysqli_query($conn,$sql) ;

// the same id in both quote and scanned table must be the same


if (mysqli_num_rows($data) > 0) {
   while( $row = mysqli_fetch_assoc($data)   ) {       

        $loc=$row['current'];
        $idNum=$row['scanned']; 
      
        $idNum=intdiv($idNum, 100000);
      
        $sql1="SELECT * FROM `quote` WHERE id=$idNum;" ; 
        $data1=mysqli_query($conn,$sql1) ;        
        $row1 = mysqli_fetch_assoc($data1)   ;        
       // tell here only to update the location not creat a new case
       if(isset($row1['sourceCode']) && isset($row1['destinationCode'])){
       if (strcmp($row1['location'],"Delivered")!=0){
          
       if($loc==$row1['sourceCode']  ){
        
        $sql2="UPDATE `quote` SET `location`='on process' WHERE id=$idNum;";
        $data2=mysqli_query($conn,$sql2) ; 
         }
        elseif($loc==$row1['destinationCode'])  {
        $sql3="UPDATE `quote` SET `location`='on delivery' WHERE id=$idNum";
        $data3=mysqli_query($conn,$sql3) ;}
       }}}}
if(isset($_POST['delete'])&& !empty($_SESSION["newsession"])){
$idDelete=$_SESSION["newsession"];
if(isset($idDelete)&&!empty($idDelete)){
$sql="DELETE FROM `quote` WHERE id=$idDelete" ; 
$data=mysqli_query($conn,$sql) ;}

}
if(isset($_POST['d'])){
  $_SESSION["daw"]=$_POST['d'];//to download the label 
 
 header('Location:show.php');}



if(isset($_SESSION["daw"]) && !empty($_SESSION["newsession"]) ){
$idValue=$_SESSION["newsession"];
$sql5="UPDATE `quote` SET `location`='pick up' WHERE id=$idValue;" ;
// remember that this id is the row number  
$data5=mysqli_query($conn,$sql5) ;
 
$sql="select * FROM quote WHERE id=$idValue" ; 
$data=mysqli_query($conn,$sql) ;
$row=mysqli_fetch_assoc($data) ; 
if($row['destinationCode']<10){
  if($row['area']<10) $track=$row['id'].$row['zone'].'0'.$row['destinationCode'].'0'.$row['area'];
  else $track=$row['id'].$row['zone'].'0'.$row['destinationCode'].$row['area'];
}
else{
  if($row['area']<10) $track=$row['id'].$row['zone'].$row['destinationCode'].'0'.$row['area'];
  else $track=$row['id'].$row['zone'].$row['destinationCode'].$row['area'];
} 

$generator = new Picqer\Barcode\BarcodeGeneratorPNG();
file_put_contents('barcode.png', $generator->getBarcode($track, $generator::TYPE_CODE_128, 8, 70));

   $pdf = new FPDF('p','mm','A4');
   $pdf->AddPage();
   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(180,10,"Easy2Go",'0','0','C');
   //$pdf->Image('logo.png',85,-10);
   $pdf->line(10,25,200,25); //(x1,y1,x2,y2)
   $pdf->Ln(22);
   $pdf->SetFont('Arial','b',18);

   $pdf->Cell(25,10,"FROM:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(105,10,$row['source']." , ".$row['sourceCity'],'0','0','a');

   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(30,10,"CODE:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(20,10,$row['sourceCode'],'0','1','a');

   $pdf->line(10,65,200,65);
   $pdf->Ln(5);
   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(30,10,"SHIP TO:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(100,10,$row['destination']." , ".$row['destinationCity']." ".$row['restaddress'],'0','0','a');

   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(30,10,"CODE:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(20,10,$row['destinationCode'],'0','1','a');
   $pdf->Ln(16);
   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(45,10,"DIM WEIGHT:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(6,10,$row['DimActual'],'0','0','a');// change this to dim weight
   $pdf->Cell(8,10,"kg",'0','1','a');
   $pdf->line(10,90,200,90);
   /*
   $pdf->Ln(12);
   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(20,10,"ID nr:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(8,10,$row['id'],'0','0','a');
   */
   $pdf->line(10,110,200,110);
   $pdf->Ln(12);
   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(40,10,"FULLNAME:",'0','0','a');
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(20,10,$row['fullName'],'0','1','a');
   $pdf->line(10,130,200,130);
   $pdf->Ln(10);
   $pdf->SetFont('Arial','b',18);
   $pdf->Cell(55,10,"TRACKING NB:",'0','0','a');//tacking num
   $pdf->SetFont('Arial','',16);
   $pdf->Cell(20,10,$track,'0','1','a');
   
   $pdf->Image('barcode.png',25,155,160);
   $pdf->Ln(30);
   //$pdf->Cell(180,30," 081231723897",'0','1','C');// remeber to replace that number with the variable 
   $pdf->Image('images/stamp.png',150,225,45);
   $pdf->Ln(30);
   $pdf->Cell(100,10,"",'0','0','a');
   $pdf->Cell(20,10,"Received on ".date("l")."  ".date("Y/m/d"),'0','0','a');// add the date class
   $pdf->Output(); 

  }?>
 


<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="style.css?v20">
  
  <script src="https://kit.fontawesome.com/d293919c65.js" crossorigin="anonymous"></script>
</head>
<body>

  <div class="side">
  <a href="http://localhost/mainPage/" ><i class="fa-solid fa-house"></i></a>
   <h2 class="vertical">Admin's space</h2>
  </div>
 <div  class="logOut" >  
   <form action="index.php" method="post">
    <input type="submit" value="LogOut" name="logout">
   </form>
 </div>
 <div  class="hestory" >  
   <form action="show.php" method="post">
   <input type="date"  name="dateEntered"><br>
    <input type="submit" value="Delete now!" name="hestory">
   </form>
 </div>
 <div  class="mail" >  
   <form action="show.php" method="post">
    <input type="submit" value="Send mail!" name="m">
   </form>
 </div>
<?php
if(isset($_POST['m'])){
  $_SESSION['sendMail']=$_POST['m'];
  header('Location:show.php');
}
?>
<?php 

 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\SMTP;
 use PHPMailer\PHPMailer\Exception;
  if(isset($_SESSION['sendMail'])){
    //Load Composer's autoloader
    require 'vendor/autoload.php';
    
    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);
        //Server settings
    
      // $mail->SMTPDebug = 3;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.mail.yahoo.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'userName@yahoo.com';                     //SMTP username
        $mail->Password   = 'password';                               //SMTP password
        $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        
        //Recipients
        $mail->setFrom('userName@yahoo.com', 'Easy2go delivery agency');
    
        $sql="SELECT * FROM `quote`;" ; 
        $data=mysqli_query($conn,$sql) ;
        
        
        if (mysqli_num_rows($data) > 0) {
           while( $row = mysqli_fetch_assoc($data)   ) {    
          if(strcmp($row['location'],"on delivery")==0){
            $mail->addAddress($row['Email']);     //Add a recipient
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'About your package';
            $mail->Body    = 'Hello Mr/Mrs '.$row['fullName'].', your package has succesfly arrived to <b>the final destination </b>';
           /* $mail->AltBody = 'Hello Mr/Mrs '.$row['fullName'].', your package has succesfly arrived to the final destination ';*/
           $idNum=$row['id'];
           $sql2="UPDATE `quote` SET `location`='Delivered' WHERE id=$idNum;";
           $data2=mysqli_query($conn,$sql2) ;
           $mail->send();
           
           
        }
        
        
            }}  
  }
?>
 <?php
  if(isset($_POST['hestory'])){
    $_SESSION['hes']=$_POST['hestory'];
    $_SESSION['da']=$_POST['dateEntered'];
    header('Location:show.php');
  }
  if(isset($_SESSION['hes'])){
    $sql12="SELECT * FROM quote ";
               $result12=mysqli_query($conn,$sql12);           
                if (mysqli_num_rows($result12) > 0) {
                 while(   $row = mysqli_fetch_assoc($result12)) {
              
    if(((int)date('Y',strtotime($row['quoteTime'])))< ((int)date('Y',strtotime($_SESSION['da'])))){
      $t= $row['id'];
      $sql13="DELETE FROM `quote` WHERE id=$t" ; 
      $data=mysqli_query($conn,$sql13) ;}
    
    elseif(((int)date('Y',strtotime($row['quoteTime'])))== ((int)date('Y',strtotime($_SESSION['da'])))){
      if(((int)date('m',strtotime($row['quoteTime'])))< ((int)date('m',strtotime($_SESSION['da'])))){
        $t= $row['id'];
        $sql13="DELETE FROM `quote` WHERE id=$t" ; 
        $data=mysqli_query($conn,$sql13) ;}
      elseif(((int)date('m',strtotime($row['quoteTime'])))==((int)date('m',strtotime($_SESSION['da'])))){
        if(((int)date('d',strtotime($row['quoteTime'])))<=((int)date('d',strtotime($_SESSION['da'])))){
          $t= $row['id'];
        
          $sql13="DELETE FROM `quote` WHERE id=$t" ; 
          $data=mysqli_query($conn,$sql13) ;
       }
      }}
                    

                                             }}
                               }
 ?>
 <?php
 if(isset($_POST['logout']))
  {
    session_destroy();
    //header('Location:index.php')    ;    
  }
?>
 <h2 class="list-title">List of all  customers</h2>
 <div class="line"></div>

<div class="container-tab">
<table class="tab" >
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>FullName</th>
                    <th>PhoneNumber</th>
                    <th>Email</th>
                    <th>Source_address</th>
                    <th>Destination_address</th>
                    <th>Time</th>
                    <th>State</th>
                    <th>Delete</th>
                  </tr>
                </thead>

                <tbody>
                    <?php
                     
                       $sql2="SELECT * FROM quote ";
                      $result2=mysqli_query($conn,$sql2);

                      
                      //
                             
           
                if (mysqli_num_rows($result2) > 0) {
                 while(   $row = mysqli_fetch_assoc($result2))      {
                  if($row['destinationCode']<10){
                    if($row['area']<10) $_SESSION['T']=$row['id'].$row['zone'].'0'.$row['destinationCode'].'0'.$row['area'];
                    else $_SESSION['T']=$row['id'].$row['zone'].'0'.$row['destinationCode'].$row['area'];
                  }
                  
                  else{
                    if($row['area']<10) $_SESSION['T']=$row['id'].$row['zone'].$row['destinationCode'].'0'.$row['area'];
                    else $_SESSION['T']=$row['id'].$row['zone'].$row['destinationCode'].$row['area'];
                  } 
                if(isset($_POST['idSub'])){ 
                   
                  if(isset($_POST['idVal'])&& !empty($_POST['idVal'])){
                  $_SESSION["newsession"]=intdiv($_POST['idVal'], 100000);
                  $_SESSION['but']=$_POST['idSub'];
                  header('Location:show.php');}
                  else
                  header('Location:show.php');
                }
                  if(isset($_SESSION['but'])){
                   
                    if($row['id']==$_SESSION["newsession"]  ) {
                     
                      echo   '<tr id="active-row">
                      <td>'.$_SESSION['T'].'</td>
                      <td>'.$row['fullName'].'</td>
                      <td>'.$row['phoneNumber'].'</td>
                      <td>'.$row['Email'].'</td>
                      <td>'.$row['source'].",".$row['sourceCity'].'</td>
                      <td>'.$row['destination'].",".$row['destinationCity'].'</td>
                      <td>'.$row['quoteTime'].'</td>
                      <td>'.$row['location'].'</td>
                      <td>
                      <form class="de" action="show.php"  method="post">
                      <input  type="submit" name="delete" value="delete">
                      </form>
                      </td>
                    </tr>';}
                     else {echo   '<tr>
                      <td>'.$_SESSION['T'].'</td>
                      <td>'.$row['fullName'].'</td>
                      <td>'.$row['phoneNumber'].'</td>
                      <td>'.$row['Email'].'</td>
                      <td>'.$row['source'].",".$row['sourceCity'].'</td>
                      <td>'.$row['destination'].",".$row['destinationCity'].'</td>
                      <td>'.$row['quoteTime'].'</td>
                      <td>'.$row['location'].'</td>
                      <td>
                      <form  class="daw"action="show.php"  method="post">
                      <input type="submit" name="delete" value="delete">
                      </form>
                      </td>
                    </tr>';
                    }}
                else{
                    echo   '<tr>
                    <td>'.$_SESSION['T'].'</td>
                    <td>'.$row['fullName'].'</td>
                    <td>'.$row['phoneNumber'].'</td>
                    <td>'.$row['Email'].'</td>
                    <td>'.$row['source'].",".$row['sourceCity'].'</td>
                    <td>'.$row['destination'].",".$row['destinationCity'].'</td>
                    <td>'.$row['quoteTime'].'</td>
                    <td>'.$row['location'].'</td>
                    <td>
                      <form  class="daw"action="show.php"  method="post">
                      <input  type="submit" name="delete" value="delete">
                      </form>
                    </td>
                    </tr>';
            
                  }
                  
       
                }
                } 
                

                  ?>
    </tbody>
</table>    
</div>        
 <div class="id-container">
   <form action="show.php" method="post" class="id-form">
     <input type="text" class="id-in" placeholder="Enter an ID number" name="idVal">
     <input type="submit" value="submit" name="idSub" class="id-sub">
   </form>
  </div>
  <form  class="dawn"action="show.php"  method="post">
    
    <i class="fa-solid fa-download"></i> 
  
    <input type="submit" name="d" value="Download">
    
              </form>







</body>
</html>
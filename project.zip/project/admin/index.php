

<?php 
session_start();
unset($_SESSION["newsession"]);
unset($_SESSION["daw"]);
unset($_SESSION['but']);
unset($_SESSION['valid']);
unset($_SESSION['hes']);
unset($_SESSION['da']);
unset($_SESSION['sendMail']);
include_once "../mainPage/connexion/submit.php" ;?>
<?php
 if(isset($_POST["adminSubmit"])){

     $userNameValue=$_POST["admin"];
     $passwordValue=$_POST["adminPassword"];
     
     
     if($userNameValue==""&& $passwordValue==NULL)   
       header('Location:index.php?error= userName and password are required');

     elseif($userNameValue=="")
        header('Location:index.php?error=userName is required');

     elseif($passwordValue==NULL)
       header('Location:index.php?error=password is required');

     
    else{
		$sql = "SELECT * FROM users WHERE admin_name='$userNameValue' AND password ='$passwordValue'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
          
			$row = mysqli_fetch_assoc($result);
            
            if ($row['admin_name'] === $userNameValue && $row['password']===$passwordValue) {
            	$_SESSION['valid']=true; 
            	header("Location: show.php");
		        exit();
            }else{
				header("Location: index.php?error=Incorrect user name or password");
		        exit();
			}
		}else{
            
			header("Location: index.php?error=Incorrect user name or password");
	        exit();
		}
	}
	
}
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css?1">
    <script src="https://kit.fontawesome.com/d293919c65.js" crossorigin="anonymous"></script>
    <title>Admin page </title>
</head>
<body>
   <div class="container">
      
       <form method="post" action="index.php">
       <!--i class="fa-solid fa-user-gear"></i>   -->
       <h2>Login</h2>

       <?php if(isset($_GET['error'])) { ?>
          <p class="error">  <?php echo $_GET['error']?> </p>
         <?php }?> 

       <label > Admin  </label> <br>
        <div class="i">
            <input type="text" name="admin" placeholder="Enter your name"> <i class="fa-solid fa-user"></i>  
        </div><br>
        <label > Password</label> <br>
        <div class="i">
          <input type="password" name="adminPassword"  placeholder="Enter your password"><i class="fa-solid fa-lock"></i>
        </div> <br><br>
       
       <input type="submit" name="adminSubmit" value="Login" class="admin_btn">
   </div>
   
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css?<?php echo time(); ?>">
    <script src="https://kit.fontawesome.com/d293919c65.js" crossorigin="anonymous"></script>
    <title>readMore</title>
</head>
<body>
               
  <a href="http://localhost/mainPage/" > <i class="fa-solid fa-house"></i></a>                   
                 
        <!-- Services -->
<section class="page-section" id="Services">
<div class="main-container">
     <h2 class="title" >Delivery steps</h2>
     <div class="line"></div>
     <p class="price-info"> Check the list of our offices by clicking <a href="location.pdf">here</a></p>

    <div class="container" >
        
            <div class="box">
              <p style="color:  #223350; font-size: 5em">1</p>
              <h3 style="color:  #D91A1A;">Warehouse</h3>
              <p style="color:  #223350;">
              You drop off your parcels at one of our offices near your location  
            </div>
        
           
        
            <div class="box two">
              <p style="color:  #223350; font-size: 5em">2</p>
              <h3 style="color:  #D91A1A;" >Send</h3>
              <p style="color:  #223350;" >
                We send your parcels<br /> Plus we offer the ability to  track the progress on this site
              </p>
            </div>
       
    
       
            <div class="box">
              <p style="color:  #223350; font-size: 5em">3</p>
              <h3 style="color:  #D91A1A;">Reception</h3>
              <p style="color: #223350;">
              Your recipient receives your parcels<br />
              </p>
            </div>
    </div>
</div>   
    <div class="pricing" id="findPrice">
        <h2 class="title1" >Pricing</h2>
        <div class="line"></div>
        

        <p class="method-content"> Our pricing is determined by 2 factors <br>
    <div  class="method">
   
       <div class="dim">
    <p>The DIM weight <i class="fa-solid fa-weight-hanging"></i> </p><br>
 
    <span class="dimFormula">DIM weight= length*height*width/ dimensional weight constant </span><br> where the dimensional weight constant
    is 5000 for our company <br> 
    to learn more about DIM weight <a href="https://shippingchannel.fedex.com/en-gb/preparing-shipment/shipping-costs/dimensional-weight.html#:~:text=To%20calculate%20the%20dimensional%20weight,DIM%20weight%20is%203%20kg.">click here</a>
    </div>
    <div class="distance">

      <p>The distance  <i class="fa-solid fa-road"></i></p><br>
        The longer the distance the heigher the price, we first estimated the distance between the 
        two end points in KM <br>
        
    </div>
   
    

   </div>
   <div class="factor">

<p>Once the two factors are determined we use this formula
 <span class="formula">Price =(DIMweight*100da) + (distance*100da)</span> </p>

</div>

  
        <div class="btn_container">
                 <div class="btn">
                     <a href="http://localhost/mainPage/#getQuote" > Get a quote</a>
                 </div>
                 
        </div>

   </div>           
 



</section>    
</body>
</html>
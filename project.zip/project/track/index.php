<?php
session_start();
include_once "../mainPage/connexion/submit.php";

$sql="SELECT * FROM `scannedcode`;" ; 

$data=mysqli_query($conn,$sql) ;

// the same id in both quote and scanned table must be the same


if (mysqli_num_rows($data) > 0) {
   while( $row = mysqli_fetch_assoc($data)   ) {       

        $loc=$row['current'];
        $idNum=$row['scanned']; 
      
        $idNum=intdiv($idNum, 100000);
        
        $sql1="SELECT * FROM `quote` WHERE id=$idNum;" ; 
        $data1=mysqli_query($conn,$sql1) ;        
        $row1 = mysqli_fetch_assoc($data1)   ;        
       // tell here only to update the location not creat a new case
       if(isset($row1['sourceCode']) && isset($row1['destinationCode'])){
        if (strcmp($row1['location'],"Delivered")!=0){
       if($loc==$row1['sourceCode']){
        
        $sql2="UPDATE `quote` SET `location`='on process' WHERE id=$idNum;";
        $data2=mysqli_query($conn,$sql2) ; 
         }
        elseif($loc==$row1['destinationCode'])  {
        $sql3="UPDATE `quote` SET `location`='on delivery' WHERE id=$idNum";
        $data3=mysqli_query($conn,$sql3) ;}
       }}}}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css?v7">
    <script src="https://kit.fontawesome.com/d293919c65.js" crossorigin="anonymous"></script>
    <title>tracking</title>
</head>
<body>
     
        <?php

        $idval=intdiv($_SESSION["idTrack"], 100000);
        
        $sql6="select *  FROM quote  WHERE id=$idval;" ; 
        $data6=mysqli_query($conn,$sql6) ;
        $row6=mysqli_fetch_assoc($data6) ;
       if(isset($row6['location'])) {
        echo'<div class="container">
        <p class="title">Find out the state of your  parcel!</p>
     
        <img src="pic/process.png" alt=" the whole process" width="530px">
        <p class="main">Hello Mr/Mrs '?><?php echo $row6['fullName'];?> <?php echo', the holder of  the id '?><?php echo $_SESSION["idTrack"];?><?php echo'<br> the state of your parcel is </p>
        <img src="pic/red.png" class="arrow" width="200px">
        <img src="pic/v2.png" class="arrow1" width="200px">';
        $str=$row6['location'];
         if(strcmp($str,"pick up")==0)
         echo '<img src="pic/pickup.png" alt="pickup pic">';
         elseif(strcmp($str,"on process")==0)
         echo '<img src="pic/on process.png" alt="pickup pic">';
         elseif(strcmp($str,"on delivery")==0)
         echo '<img src="pic/on delivery.png" alt="pickup pic">';
         elseif(strcmp($str,"uncollected")==0)
          echo'<br> <br>'."Not collected yet ";
          elseif(strcmp($str,"Delivered")==0)
          echo '<img src="pic/delivered.png" alt="pickup pic">';}
          else
            echo '<div class="container">
                  INVALID Tracking number
                   <br>
                   <a class="ad" href="http://localhost/mainPage/#trackParcel">TRY AGAIN</a>
                   </div>';
    
        ?>
   
     

     


</body>
</html>
<?php 
session_start();
 include_once "connexion/submit.php";
 include 'fpdf184/fpdf.php' ; 
 
 require 'code/vendor/autoload.php';




 if(isset($_POST['send'])){

    $sql="select * FROM quote WHERE id=(SELECT max(id) FROM quote)" ; 
    
    $data=mysqli_query($conn,$sql) ; 
    $row=mysqli_fetch_assoc($data) ; 

    if($row['destinationCode']<10){
        if($row['area']<10) $track=$row['id'].$row['zone'].'0'.$row['destinationCode'].'0'.$row['area'];
        else $track=$row['id'].$row['zone'].'0'.$row['destinationCode'].$row['area'];
     }
   
    else{
        if($row['area']<10) $track=$row['id'].$row['zone'].$row['destinationCode'].'0'.$row['area'];
        else $track=$row['id'].$row['zone'].$row['destinationCode'].$row['area'];
    } 

    $generator = new Picqer\Barcode\BarcodeGeneratorPNG();
    file_put_contents('barcode.png', $generator->getBarcode($track, $generator::TYPE_CODE_128, 8, 70));
      
    $pdf = new FPDF('l','mm','A4');
    $pdf->AddPage();
    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(280,10,"Easy2Go",'0','0','C');
    //$pdf->Image('logo.png',85,-10);
    $pdf->line(10,25,285,25); //(x1,y1,x2,y2)
    $pdf->Ln(22);
    $pdf->SetFont('Arial','b',18);

    $pdf->Cell(30,10,"FROM:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(170,10,$row['source']." , ".$row['sourceCity'],'0','0','a');

    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(30,10,"CODE:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(20,10,$row['sourceCode'],'0','1','a');

    $pdf->line(10,65,285,65);
    $pdf->Ln(5);
    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(30,10,"SHIP TO:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(170,10,$row['destination']." , ".$row['destinationCity']." ".$row['restaddress'],'0','0','a');

    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(30,10,"CODE:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(30,10,$row['destinationCode'],'0','1','a');
    $pdf->Ln(15);
    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(30,10,"WEIGHT:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(5,10,$row['DimActual'],'0','0','a');
    $pdf->Cell(20,10,"kg",'0','1','a');
    $pdf->line(10,90,285,90);
    $pdf->Ln(13);
    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(35,10,"Full name:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(8,10,$row['fullName'],'0','0','a');
    $pdf->Ln(0);
    $pdf->line(10,110,285,110);
    $pdf->Ln(20);
    $pdf->SetFont('Arial','b',18);
    $pdf->Cell(40,10,"TRAKING nr:",'0','0','a');
    $pdf->SetFont('Arial','',16);
    $pdf->Cell(20,10,$track,'0','1','a');
    $pdf->line(10,130,285,130);
    $pdf->Ln(20);
    $pdf->Image('barcode.png',25,135,250);
    $pdf->Ln(30);
    $pdf->Cell(280,10,date("l")."  ".date("Y/m/d"),'0','1','C');// remeber to replace that number with the variable 
    $pdf->Output();
   
 }
 if(isset($_POST['send-cencel'])){
    $sql1="DELETE FROM quote WHERE id=(SELECT max(id) FROM quote)";
    $data1=mysqli_query($conn,$sql1) ;
    header('Location:receiptPage.php?answer= Your order has been cenceled!');
    // remove the button once done
 }

?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/receiptPage.css?v11">
    <script src="https://kit.fontawesome.com/d293919c65.js" crossorigin="anonymous"></script>
    
    <title>Document</title>
</head>
<body>
   <script>
       function showDiv() {
   document.getElementById('welcomeDiv').style.display = "block";
   document.getElementById('Div').style.display = "none";
 
  
}

   </script>
     
    <div class="container" >
        <div class="container1">
            <p class="title">Your label is ready !</p>
        
        </div>
        <br>
       <div class="container4">
 
        <div class="download" id="Div"   >
         <input   type="submit" name="answer" value="Confirm your order" onclick="showDiv()" />
         </div>
         
         <div id="welcomeDiv"  style="display:none;"  > 
            <form class="d" action="test.php" method="post"> 
                           
                <input type="submit" name="send" value="Download your label"><br>
              
             </form>
              
           <p class="office">Please approach one of our offices listed in this document <a  class="name" href="location.pdf">here</a></p>   
           <p  class="note">Attach the downloded label with your package </p>  
       </div>
            <!--   
             <form class="download" action="test.php" method="post">
                <input type="submit" name="c" value="Cencel your order ">
             </form> 
         
             -->
        </div>
       
        <div class="container2">
            <p>Your shippment price is: <span> 1720DA</span></p>
        </div>
        <div class="container3">
            <p>To check our pricing method  </p>
            <i class="fa-solid fa-hand-holding-dollar"></i><br>
            <a href="http://localhost/readmore/#findPrice">click here</a></p>
        </div>
        <div  class="cencel" >
           <form action="test.php" method="post"  >
                 <input  type="submit" name="send-cencel"  value="Cencel your order" >
                 <i class="fa-solid fa-face-frown"></i>
                 
            </form>
            
        </div>
        <div>
       <?php if(isset($_GET['answer'])) { ?>
                    <p class="answer">  <?php echo $_GET['answer']?> </p>
                <?php }?> 
        </div>

        
        
    </div>

</body>

</html>
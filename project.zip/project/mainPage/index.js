window.onload=function(){
const toggleBtn=document.getElementsByClassName('toggle')[0];
const navlink=document.getElementsByClassName('nav-bar-link')[0];
            toggleBtn.addEventListener('click',()=>{
            navlink.classList.toggle('active')}
            )}
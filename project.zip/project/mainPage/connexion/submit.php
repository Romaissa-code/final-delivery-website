<?php
$servername="localhost";
$username="root"; 
$password=""; 
$dbname="db1";

$conn= new mysqli($servername,$username,$password,$dbname); 

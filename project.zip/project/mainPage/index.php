<?php 
session_start();
include_once "connexion/submit.php"; ?>

 <!-- this is to insert the entered values to the database -->

 
     <!-- the values from the tracking part -->
<?php 
        if(isset($_POST["send_track"])){

            $track=$_POST["tracking"]; 
            $_SESSION["idTrack"]=$track;
           // $result=mysqli_query($conn,"INSERT INTO `track`(`track_num`) VALUES ('$track') ");
           // if($result){
                header('Location:http://localhost/track/');// make it go to tracking info page
           //     exit;
           // }
        };
 ?>
    <!-- the values from sending a quote part -->
<?php

  if(isset($_POST["send_quote"] )){
            $f=$_POST["fullName"] ; 
            $p=$_POST["phoneNumber"] ; 
            $s=$_POST["source"] ; // source wilaya
            $d=$_POST["destination"] ; //destination wilaya
            $l=$_POST["length"] ; 
            $h=$_POST["height"] ;
            $we=$_POST["weight"] ; 
            $e=$_POST["email"] ; 
            $sc=$_POST["source-city"] ; //source city
            $dc=$_POST["source-destination"] ; //destination city
            $restadres=$_POST["rest"] ; 
   
            // here i inserted the the location manually ( for testing only )
                // in a real scenario a database must be used 
            $wilaya =array (  
                "alger"=>"16",
                "boumerdes"=>"35",
                "tipaza"=>"42",
                "blida"=>"09",
                
            );
            $city =array ( 
                "bab el oued"=>"1", 
                "rouiba"=>"2",
                
                "boudouaou"=>"3",
                "boumerdes"=>"4",

                "kolea"=>"5",
                "cherchell"=>"6",

                "boufarik"=>"7",
                "mouzaia"=>"8",
            );
            $s_lower=strtolower($s); 
            $d_lower=strtolower($d); 

            $sc_lower=strtolower($sc); 
            $dc_lower=strtolower($dc);
            // to divide the location to a specific zone and region (need for sorting)
            if((strcmp($d_lower,"alger")==0) or (strcmp($d_lower,"boumerdes")==0) ){
                $zone=1;
            }
            elseif((strcmp($d_lower,"tipaza")==0)or(strcmp($d_lower,"blida")==0)){
                $zone=2;
            }

            if((strcmp($dc_lower,"bab el oued")==0)  ){
                $area=1;
            }
            elseif((strcmp($dc_lower,"rouiba")==0)){
                $area=2;
            }
            if((strcmp($dc_lower,"boudouaou")==0)  ){
                $area=3;
            }
            elseif((strcmp($dc_lower,"boumerdes")==0)){
                $area=4;
            }
            elseif((strcmp($dc_lower,"kolea")==0)){
                $area=5;
            }
            elseif((strcmp($dc_lower,"cherchell")==0)){
                $area=6;
            }
            elseif((strcmp($dc_lower,"boufarik")==0)){
                $area=7;
            }
            elseif((strcmp($dc_lower,"mouzaïa")==0)){
                $area=8;
            }

            settype($we,'float');settype($h,'float');settype($l,'float');
            $DIM=($we*$h*$l)/5000; // formula to calculate the DIM weight
            
            if($we>$DIM) $DimActual=$we; // use the actual weight
            else $DimActual=$DIM;

            $sql="INSERT INTO `quote`(`fullName`, `phoneNumber`, `source`,`sourceCity`,`destination`,`destinationCity`, `DimActual`,`Email`,`sourceCode`,`destinationCode`,`restaddress`,`zone`,`area`,`location`,`quoteTime`) VALUES ('$f','$p','$s','$sc','$d','$dc','$DimActual','$e','$wilaya[$s_lower]','$wilaya[$d_lower]','$restadres','$zone','$area','uncollected',CURRENT_TIMESTAMP) ";
            $result=mysqli_query($conn,$sql);
            

            $sql1="SELECT* FROM `quote`WHERE id=(SELECT max(id) FROM quote)";
            $result1=mysqli_query($conn,$sql1);
            $row= mysqli_fetch_assoc($result1);
        
            if($result){
                header('Location:receiptPage.php');
                exit;
            }
   
             }
            
           
   
            
            
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>frontEnd design </title>
    <link rel="stylesheet" href="CSS/index.css?v11">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400;700&family=Roboto+Condensed:wght@400;700&display=swap" rel="stylesheet">
    <script src="index.js"></script>
    <script src="https://kit.fontawesome.com/d293919c65.js" crossorigin="anonymous"></script>
</head>
<body>
        
        <nav>
            <div class="logo">Easy<span class="logo-span">2</span>Go.com</div>

            <div class="nav-bar">
                <a href="#" class="toggle">
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                    <span class="toggle-bar"></span>
                 </a>
                <ul class="nav-bar-link">
                    
                    <li><a href="#services">Services</a></li>
                    <li><a href="#trackParcel">Track your parcel </a></li>
                    <li><a href="#getQuote">Get a quote</a></li>
                    <li><a href="#contactUs">Contact us</a></li>
                    <li><a href="http://localhost/ADMIN/" >Admin's space</a></li>
                </ul>
            </div>
        </nav>
        

        <div class="main" id="homeContent">
              
            <div class="main-passage">
             <p> The Best Parcel Delivery in Algeria </p> 
                 <ul class="list">
                     <li><i class="fa-solid fa-square-check"></i>Fast Delivery</li>
                     <li><i class="fa-solid fa-square-check"></i>Real Time Tracking</li>
                     <li > <i class="fa-solid fa-square-check"></i>Affordable Prices</li>
                 </ul>
                 <img class="road" src="images/no.jpg" alt="" width="250px"height="250px">
                 <div class="btn">
                     <a href="#getQuote" > Get a quote</a>
                 </div>

            </div>
            <div class="resp">
            <p> The Best Parcel Delivery in Algeria </p> 
            
            <ul class="list">
                     <li><i class="fa-solid fa-square-check"></i>Fast Delivery</li>
                     <li><i class="fa-solid fa-square-check"></i>Real Time Tracking</li>
                     <li > <i class="fa-solid fa-square-check"></i>Affordable Prices</li>
                 </ul>
            <div class="btn res">
                     <a href="#getQuote" > Get a quote</a>
                 </div>
            </div>

            <div class="main-img">  
                <img src="images/d2.png" alt="a man" width="650px" height="680px" >
            </div> 
        </div>
        
        
       <section class="s" id="services">
         <div class="service-t">
                <h1 >Service</h1>
         </div>

         <div class="services">   

            <div class="ser1">
                <i class="fa-solid fa-people-carry-box"></i>
                <h2>Classic  delivery </h2>
                <p> We get your parcels to their destination 
                    in no time , with a reasonable  price </p>
                <a class ="planning" href="planning.pdf">Check our planning schedule</a><br>
              <div class="btn one"><a href="http://localhost/readmore/"  class="link">Read more</a></div>
           </div>
            <div class="ser3">
                <i class="fa-solid fa-earth-africa"></i>
                <h2>Real time tarcking</h2>
                <p>Just insert your tracking number and find out the location of your parcel</p>
                <br><br>
                <div class="btn three"> <a href="https://www.shiprocket.in/blog/courier-parcel-package-tracking-system-working/" class="link"> Check how it works!</a>   </div>
            </div>
        </div>

    </section>

    <div class="block" id="trackParcel">
     
        <div class="block-img">
           
            <img src="images/process.png" alt="" width="700px" >
        </div>
        <div class="t-inbtn">
            <h2>Track your parcel <i class="fa-solid fa-location-dot"></i></h2>
            <p>Insert your tracking number to locate your parcel any time</p> 

            <form  method="post" action="index.php" class="inbtn">     
                <input type="text" placeholder="xx-xx-xx" id="t-btn1" name="tracking" >
                <input type="submit" id="t-btn2" name="send_track" value="submit">
            </form>   

        </div> 
    </div>
      


    <div class="main2" id="getQuote">
            <div class="forum">
                <div class="f-title">
                    <h2>Get a quote </h2>
                </div>

                <form action="index.php" method="post" class="main-form">
                <div class="forum-div">
                    <label >Full name</label><br>
                    <input type="text" name="fullName" required><br>
                </div>
                <div class="forum-div">
                    <label >Phone number</label><br>
                    <input type="text" name="phoneNumber" required><br>
                </div>
                
                <div class="forum-div">
                    <label>Source address</label><br>
                    <input id="adress"  type="text" placeholder="Source Wilaya" name="source" required>
                    <input id="adress" type="text" placeholder="Source City" name="source-city" required>
                    
                
                </div>
                <div class="forum-div">
                    <label >Desstination address</label><br>
                    <input id="ad" type="text"placeholder="Destination Wilaya" name="destination" required>
                    <input id="ad" type="text" placeholder="Destination City" name="source-destination" required><!-- add this to the database-->
                    <input id="ad" type="text"placeholder="Rest" name="rest" >
                
                </div>
            
                   <div class="forum-div">
                      <label>Length</label> 
                       <input type="text" placeholder="cm" name="length" required>
                    </div>
                    <div class="forum-div">
                        <label>Height</labeel>
                        <input type="text" placeholder="cm" name="height"required>
                    </div>
                    
                    <div class="forum-div">
                        <label>Weight</label>
                        <input type="text" placeholder="kg" name="weight"required>
                    </div>
                    <div class="forum-div">
                       <label>Email</label> 
                        <input type="email" name="email" required>
                    </div>
                       
                       <input type="submit" value="send" name="send_quote" class="btn2" >
                       
                       </form>
                    
                   
                </div>
                
            </div>
            
        </div>
       

        <div class="c" id="contactUs">
            <div class="conact">
             <h2 class="conact-title">Contact us</h2>   
            <div class="contact-info">
                <p>Boulevard de l'independance 35000 Boumerdes-Algerie</p>


                <p>(+213) 0560 477 356 63</p>
                <p>contact@Easy2Go.com</p>
            </div>
        </div>
       
    </div>
    <footer>
        <div class="close">Easy2Go &copy:2022</div> 
    </footer>
</body>
</html>